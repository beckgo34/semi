package kr.co.icia.mapline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MapLineApplication {

	public static void main(String[] args) {
		SpringApplication.run(MapLineApplication.class, args);
	}

}
