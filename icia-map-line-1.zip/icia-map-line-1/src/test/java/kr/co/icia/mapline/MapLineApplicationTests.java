package kr.co.icia.mapline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MapLineApplicationTests {

	@Test
	void contextLoads() {
	}

}
