package kr.co.icia.vrp.semi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VrpSemiApplication {

	public static void main(String[] args) {
		SpringApplication.run(VrpSemiApplication.class, args);
	}

}
