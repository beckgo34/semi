package kr.co.icia.vrp.semi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VrpSemiApplicationTests {

	@Test
	void contextLoads() {
	}

}
